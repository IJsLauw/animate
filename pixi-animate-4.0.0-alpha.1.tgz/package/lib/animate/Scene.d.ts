import type { MovieClip } from './MovieClip';
import { Application } from 'pixi.js';
import type { EventEmitter, DestroyOptions } from 'pixi.js';
import type { AnimateAsset } from '../AnimateAsset';
/**
 * Extends the PIXI.Application class to provide easy loading.
 * Note (v8): Application requires async initialization before use:
 * ```
 * const scene = new PIXI.animate.Scene();
 * await scene.init({ width: 800, height: 600 });
 * scene.load(lib.StageName);
 * ```
 */
export declare class Scene extends Application {
    /**
     * Reference to the global sound object
     * @readOnly
     */
    readonly sound: EventEmitter;
    /**
     * The stage object created.
     */
    instance: MovieClip;
    /**
     * Load a stage scene and add it to the stage.
     * @param asset - Reference to the scene to load.
     * @param complete - Callback when finished loading.
     * @param basePath - Optional base directory to prepend to assets.
     * @return instance of PIXI resource loader
     */
    load(asset: AnimateAsset, complete?: (instance?: MovieClip) => void, basePath?: string): void;
    /**
     * Destroy and don't use after calling.
     * @param removeView - Automatically remove canvas from DOM.
     * @param stageOptions - Options parameter. A boolean will act as if all options
     *  have been set to that value
     */
    destroy(removeView?: boolean, stageOptions?: DestroyOptions | boolean): void;
}
